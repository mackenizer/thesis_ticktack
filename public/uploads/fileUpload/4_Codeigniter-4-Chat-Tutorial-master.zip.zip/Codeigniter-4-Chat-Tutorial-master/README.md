# CodeIgniter 4 Real Time Chat Application
This are the project files used in YouTube tutorial
> https://www.youtube.com/watch?v=9qIIjv17IgQ

### 1. Download & Install
Once cloned, open terminal and navigate inside the project folder, then run:
> composer install

### 2. Setup
Create a new database. DO NOT create any tables yet. Create .env file (a duplicate of 'env' sample file) and uncomment default.database block. Then also change the database connection details, after that run in your terminal:
> php spark migrate

This will create the tables that are required for the CodeIgniter 4 Chat Tutorial

### 3. Register users
Tables in your database are empty, so you will have to create users yourself through the registration form.

### 4. Enjoy the tutorial.
